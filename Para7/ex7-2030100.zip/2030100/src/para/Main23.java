// 学籍番号：20B30100
// 氏名：伊藤悠馬
package para;

import para.Main15;

/** スライダにより画像処理効果が変わるプログラム
 */
public class Main23 extends Main15{
    public Main23(){
        super("imagefilter.cl", "Filter9");
    }
}